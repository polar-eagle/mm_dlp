from ctypes import *
windll.LoadLibrary("./libs/libusb-1.0.dll" )
librockmong = windll.LoadLibrary("./libs/librockmong.dll" )




