import Projector
import RMortor
import SensorFanClean
import ZMortor
import time
import yaml
import requests

class MM_DLP:
    def __init__(self):
        self.zmortor = ZMortor.ZMortor()
        self.rmortor = RMortor.RMortor()
        self.projector = Projector.Projector()
        self.sensorFanClean = SensorFanClean.SensorFanClean()
        self.projector.LedOff()


    def openGCode(self, slice_path):
        f = open(slice_path, encoding='utf-8')
        line = f.readline().strip()
        self.gcode = []
        self.gcode.append(line.split())
        while line:
            line = f.readline().strip()
            self.gcode.append(line.split())
        f.close()
        self.proj_path = None

    def print(self):
        for line in self.gcode:
            print(line)
            if line[0] == 'proj_path':
                self.proj_path = line[1]
            elif line[0] == 'tank':
                tank = int(line[1])
                if len(line) > 2:
                    acc = int(line[2])
                    dec = int(line[3])
                    speed = int(line[4])
                    self.rmortor.setSpeed(acc, dec, speed)
                self.rmortor.moveTank(tank)
            elif line[0] == 'fan':
                if line[1] == 'open':
                    self.sensorFanClean.fanOpen()
                elif line[1] == 'close':
                    self.sensorFanClean.fanClose()
            elif line[0] == 'clean':
                if line[1] == 'open':
                    self.sensorFanClean.cleanOpen()
                elif line[1] == 'close':
                    self.sensorFanClean.cleanClose()
            elif line[0] == 'glass':
                pos = float(line[1])
                if len(line) > 2:
                    acc = float(line[2])
                    dec = float(line[3])
                    speed = float(line[4])
                    self.zmortor.setGlassSpeed(acc, dec, speed)
                self.zmortor.glassMove(pos)
            elif line[0] == 'plate':
                pos = float(line[1])
                if len(line) > 2:
                    acc = float(line[2])
                    dec = float(line[3])
                    speed = float(line[4])
                    self.zmortor.setPlateSpeed(acc, dec, speed)
                self.zmortor.plateMove(pos)
            elif line[0] == 'proj':
                # path = self.proj_path + line[1]
                path = line[1]
                display_time = float(line[2])
                cur = int(line[3])
                self.projector.showOnProj(path, 1, display_time,cur)
            elif line[0] == 'wait':
                time.sleep(float(line[1]))
            elif line[0] == 'capture':
                requests.get(url='http://172.25.112.51:8080/gopro/camera/shutter/start')
            elif line[0] == 'cameraMode':
                requests.get(url='http://172.25.112.51:8080/gopro/camera/presets/set_group?id=1001')
                requests.get(url='http://172.25.112.51:8080/gopro/camera/control/wired_usb?p=1')


f = open('./config.yaml')
config = yaml.load(f, Loader=yaml.FullLoader)
f.close()
a=MM_DLP()
a.projector.LedOff()
a.openGCode('%srun.gcode'%config['export_path'])
a.print()
a.zmortor.disableAllActuators()
# a.zmortor.plateMove(80)
# a.zmortor.glassMove(0)
# a.projector.showOnProj('./_O/1_0.png',1,2,100)
