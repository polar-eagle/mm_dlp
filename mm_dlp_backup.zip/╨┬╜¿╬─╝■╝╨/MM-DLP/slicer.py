import os
import yaml
import cv2
import numpy as np
import shutil
import os

f = open('./config.yaml')
config = yaml.load(f, Loader=yaml.FullLoader)
f.close()
# -------------------- dp算路径 -----------------------
layers = []
for i in range(config['material_num']):
    layers.append(0)
    for filename in os.listdir(config['img_path_' + str(i)]):
        if filename[-3:] == 'png' and filename[:-4].isdigit():
            layers[i] = max(layers[i], int(filename[:-4]))
n = max(layers)
m = config['material_num']
a = np.zeros((n + 1, m), int)  # a[i][j]表示第i层第j个槽位 图片有几个白色像素
b = np.zeros((n + 1), int)  # b[i]表示第i层有几个槽位需要打印
for i in range(1, n + 1):
    for j in range(m):
        if i <= layers[j]:
            img = cv2.imread('%s%d.png' % (config['img_path_%d' % j], i), cv2.IMREAD_GRAYSCALE)
            a[i][j] = cv2.countNonZero(img)
            if a[i][j] > 0:
                b[i] += 1
f = np.full((n + 1, m), m * n, int)
g = np.full((n + 1, m), -1, int)
for j in range(m):
    f[0][j] = 0
for i in range(1, n + 1):
    for j in range(m):
        if a[i][j] > 0:
            for k in range(m):
                if f[i][j] > f[i - 1][k] + b[i] - (1 if a[i][k] > 0 else 0) + (1 if j == k and b[i] > 1 else 0):
                    f[i][j] = f[i - 1][k] + b[i] - (1 if a[i][k] > 0 else 0) + (1 if j == k and b[i] > 1 else 0)
                    g[i][j] = k
ed_tank = [0]

change_times = n * m
for i in range(m):
    if f[n][i] < change_times:
        change_times = f[n][i]
        ed_tank[0] = i
print(change_times)
for i in range(n, 0, -1):
    ed_tank.append(g[i][ed_tank[-1]])

ed_tank.reverse()
# -------------------- dp算路径 -----------------------
if os.path.exists(config['export_path'][:-1]):
    for i in os.listdir(config['export_path'][:-1]):
        os.remove(config['export_path'] + i)
else:
    os.makedirs(config['export_path'][:-1])

f = open(config['export_path'] + 'run.gcode', 'w')
if config['lapse']:
    f.write('cameraMode\n')
f.write('fan open\n')
f.write('clean open\n')
f.write('wait 3\n')
f.write('fan close\n')
f.write('clean close\n')
f.write('plate 150 %.2f %.2f %.2f\n' % (config['z_acc2'], config['z_dec2'], config['z_speed2']))
f.write('glass -50 %.2f %.2f %.2f\n' % (config['z_acc2'], config['z_dec2'], config['z_speed2']))
f.write('tank %d %d %d %d\n' % (ed_tank[0], config['r_acc'], config['r_dec'], config['r_speed']))
f.write('plate %.2f %.2f %.2f %.2f\n' % (20.0, config['z_acc'], config['z_dec'], config['z_speed']))
now_tank = ed_tank[0]


def printLayer(tank, layer):
    global f, config, now_tank
    src_img_path = '%s%d.png' % (config['img_path_%d' % tank], layer)
    dst_img_path = '%s%d_%d.png' % (config['export_path'], i, tank)
    # shutil.copyfile(src_img, dst_img)
    src_img = cv2.imread(src_img_path)
    top = (1080 - src_img.shape[0]) // 2
    bottom = (1081-src_img.shape[0]) //2
    left = (1920-src_img.shape[1])//2
    right = (1921-src_img.shape[1])//2
    dst_img = cv2.copyMakeBorder(src_img,top,bottom,left,right,cv2.BORDER_CONSTANT,value=(0,0,0))
    cv2.imwrite(dst_img_path,dst_img)
    height = config['layer_height'] * float(layer)
    if now_tank != tank:
        f.write('plate %.2f %.2f %.2f %.2f\n' % (5.0 + height, config['z_acc'], config['z_dec'], config['z_speed']))
        f.write('plate %.2f %.2f %.2f %.2f\n' % (95.0 + height, config['z_acc2'], config['z_dec2'], config['z_speed2']))
        f.write('glass -50 %.2f %.2f %.2f\n' % (config['z_acc2'], config['z_dec2'], config['z_speed2']))
        f.write('wait %d\n' % (40 if layer < 50 else 5))
        # --------清洗---------
        f.write('tank %d\n' % config['clean_tank'])
        f.write('clean open\n')
        f.write('plate %.2f\n' % (33.0 + height * 0.5)) #33
        f.write('wait %d\n' % 6)#6
        f.write('plate %.2f\n' % (43.0 + height * 0.5))
        f.write('plate %.2f\n' % (33.0 + height * 0.5))
        f.write('wait %d\n' % 6)
        f.write('plate %.2f\n' % (100.0 + height))
        f.write('clean close\n')#6
        f.write('wait %d\n' % (20 if layer < 50 else 5))
        # f.write('wait %d\n' % (20))
        f.write('tank %d\n' % config['fan_tank'])
        f.write('plate %.2f\n' % (60.0 + height)) #60
        f.write('fan open\n')
        # f.write('wait %d\n' % (50 if layer < 50 else 20))
        f.write('wait %d\n' % (80))
        f.write('plate %.2f\n' % (100.0 + height))
        f.write('fan close\n')

        # --------延时---------
        if config['lapse']:
            f.write('plate %.2f\n' % (150))
            f.write('tank 0\n')
            f.write('wait 1\n')
            f.write('capture\n')
            f.write('wait 1\n')
        # --------延时---------

        # --------清洗---------
        f.write('tank %d\n' % tank)
        f.write('glass 0 %.2f %.2f %.2f\n' % (config['z_acc'], config['z_dec'], config['z_speed']))
        f.write('plate %.2f\n' % (20.0 + height))
        f.write('plate %.2f %.2f %.2f %.2f\n' % (height, config['z_acc'], config['z_dec'], config['z_speed']))
        now_tank = tank
    else:
        f.write('glass %.2f\n' % 0)
        f.write('plate %.2f\n' % (height + config['back_distance']))
        f.write('plate %.2f\n' % height)

    f.write('proj %s %.2f %d\n' % (
    dst_img_path, config['bottom_exposure_time_%d' % now_tank] if layer <= config['bottom_layers'] else config[
        'standard_exposure_time_%d' % now_tank],
    config['bottom_exposure_current_%d' % now_tank] if layer <= config['bottom_layers'] else config[
        'standard_exposure_current_%d' % now_tank]))


for i in range(1, n + 1):
    if a[i][ed_tank[i - 1]] > 0:
        printLayer(ed_tank[i - 1], i)

    for j in range(m):
        if a[i][j] > 0 and j != ed_tank[i - 1] and j != ed_tank[i]:
            printLayer(j, i)

    if ed_tank[i] != ed_tank[i - 1]:
        printLayer(ed_tank[i], i)

f.write('plate %.2f\n' % (n * config['layer_height'] + 90))
f.write('glass -50 %.2f %.2f %.2f\n' % (config['z_acc2'], config['z_dec2'], config['z_speed2']))
