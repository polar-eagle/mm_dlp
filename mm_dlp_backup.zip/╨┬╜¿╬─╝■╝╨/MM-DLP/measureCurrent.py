import Projector

projector = Projector.Projector()

projector.LedOff()
# projector.showOnProj('./cleanDebris.png',1,10,100)
projector.showOnProj('./_O/1_0.png',1,10,100)