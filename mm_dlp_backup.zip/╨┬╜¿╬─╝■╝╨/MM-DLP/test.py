# import cv2
# img = cv2.imread('./_B/1.png', cv2.IMREAD_GRAYSCALE)
# print(cv2.countNonZero(img))

for i in range(3,0,-1):
    print(i)