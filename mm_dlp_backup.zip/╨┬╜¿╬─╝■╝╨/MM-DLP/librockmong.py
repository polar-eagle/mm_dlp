from ctypes import *
windll.LoadLibrary("./libs/windows/x86_64/libusb-1.0.dll" )
librockmong = windll.LoadLibrary("./libs/windows/x86_64/librockmong.dll" )




