import Projector
import RMortor
import SensorFanClean
import ZMortor


zmortor = ZMortor.ZMortor()
rmortor = RMortor.RMortor()
projector = Projector.Projector()
sensorFanClean = SensorFanClean.SensorFanClean()
projector.LedOff()
sensorFanClean.fanClose()
sensorFanClean.cleanClose()
zmortor.plateMove(0)
zmortor.glassMove(0)
# zmortor.glassMove(-50)
# rmortor.moveTank(0) #液槽
# zmortor.glassMove(0)
# zmortor.plateMove(0.1)
# projector.showOnProj('./345.png',1,100,40)
# zmortor.glassMove(-50)
# zmortor.plateMove(100)
# zmortor.disableAllActuators()