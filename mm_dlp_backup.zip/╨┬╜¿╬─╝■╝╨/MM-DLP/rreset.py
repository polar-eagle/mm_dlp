import Projector
import RMortor
import SensorFanClean
import ZMortor


zmortor = ZMortor.ZMortor()
rmortor = RMortor.RMortor()
projector = Projector.Projector()
sensorFanClean = SensorFanClean.SensorFanClean()
projector.LedOff()
sensorFanClean.fanClose()
sensorFanClean.cleanClose()
zmortor.plateMove(100)
zmortor.glassMove(0)
# rmortor.moveTank(0)
