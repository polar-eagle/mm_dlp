import ZMortor
a=ZMortor.ZMortor()
a.disableAllActuators()
