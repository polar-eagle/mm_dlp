import Projector
a=Projector.Projector()
a.LedOff()
# a.PowerOff()
# a.USB3DPrinter.PowerOnOff(True)